package com.example.apidocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDocsApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiDocsApplication.class, args);
    }

}
